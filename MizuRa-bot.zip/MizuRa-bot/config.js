module.exports = {
    prefix: '.',  // Pastiin ini titik, bukan kosong atau '/'
    botName: 'MizuRa',
    owner: '6283130595087', // Nomor lu
    // ... isi lainnya
};
