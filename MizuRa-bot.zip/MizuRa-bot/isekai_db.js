const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, './database/isekai/user_data.json');

const isekaiDB = {
    read: () => {
        if (!fs.existsSync(dbPath)) {
            fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));
        }
        return JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
    },
    write: (data) => {
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
    },
    checkUser: (db, id) => {
        if (!db[id]) {
            db[id] = {
                level: 1,
                exp: 0,
                money: 1000,
                hp: 100,      // Darah saat ini
                max_hp: 100,  // Batas darah
                inventory: [],
                lastHunt: 0
            };
        }
        // Pelindung kalau user lama belum punya properti HP
        if (db[id].hp === undefined) db[id].hp = 100;
        if (db[id].max_hp === undefined) db[id].max_hp = 100;
        return db;
    }
};

module.exports = isekaiDB;
