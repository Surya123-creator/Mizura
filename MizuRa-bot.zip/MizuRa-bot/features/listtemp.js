const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../database/user_data.json');
const readDB = () => { try { return JSON.parse(fs.readFileSync(dbPath, 'utf-8')); } catch { return {}; } };

module.exports = {
    execute: async (sock, msg, args, from) => {
        const db = readDB();
        const users = Object.keys(db);

        if (users.length === 0) {
            return sock.sendMessage(from, { text: "📭 Belum ada Temp Mail yang dibuat di database." }, { quoted: msg });
        }

        let teks = "📋 *DAFTAR TEMP MAIL TERDAFTAR*\n\n";
        
        users.forEach((jid, index) => {
            const nomer = jid.split('@')[0];
            teks += `*${index + 1}. User:* @${nomer}\n`;
            teks += `📧 *Email:* ${db[jid].email}\n`;
            teks += `──────────────────\n`;
        });

        await sock.sendMessage(from, { 
            text: teks, 
            mentions: users 
        }, { quoted: msg });
    }
};
