const fs = require('fs');
const path = require('path');
const config = require('../config');

module.exports = {
    help: 'donate',
    category: 'system', // Udah gue samain kayak menu
    desc: 'Donasi',
    execute: async (sock, msg, args, from) => {
        try {
            const qrisPath = path.join(__dirname, '../gambar/qris.jpg');
            
            let caption = `╭───「 ✦ *DONATION* ✦ 」\n`;
            caption += `│\n`;
            caption += `│ ✦ *DANA:* 083130595087\n`;
            caption += `│ ✦ *GOPAY:* 083130595087\n`;
            caption += `│ ✦ *SOCIALBUZZ:* https://sociabuzz.com/mizura/donate\n`;
            caption += `│\n`;
            caption += `╰──────────────────────\n\n`;
            caption += `_Donasi lu sangat berarti buat bayar RDP & pengembangan MizuRa-bot ke depannya._`;

            if (fs.existsSync(qrisPath)) {
                await sock.sendMessage(from, { 
                    image: fs.readFileSync(qrisPath), 
                    caption: caption 
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: caption }, { quoted: msg });
            }

        } catch (e) {
            console.error("Donet error:", e);
        }
    }
};
