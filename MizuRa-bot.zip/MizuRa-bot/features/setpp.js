const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
    help: 'setpp',
    category: 'hidden', 
    desc: 'Simpan foto profil Hero Card',
    execute: async (sock, msg, args, from) => {
        try {
            const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage || msg.message.imageMessage;
            if (!quoted) return sock.sendMessage(from, { text: "❌ Silakan reply foto yang ingin dijadikan profil dengan ketik *.setpp*" });

            const isImage = msg.message.imageMessage || msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            if (!isImage) return sock.sendMessage(from, { text: "❌ Mohon kirim atau reply sebuah foto!" });

            await sock.sendMessage(from, { text: "⏳ Sedang memproses foto profil..." });

            const target = msg.message.imageMessage ? msg.message.imageMessage : msg.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage;
            const stream = await downloadContentFromMessage(target, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const dir = './database/profiles';
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

            const filePath = path.join(dir, `${from.split('@')[0]}.jpg`);
            fs.writeFileSync(filePath, buffer);

            await sock.sendMessage(from, { text: "✅ *FOTO PROFIL DISIMPAN!*\nSekarang cek *.status* kamu." }, { quoted: msg });

        } catch (e) {
            console.error(e);
            await sock.sendMessage(from, { text: "⚠️ Gagal menyimpan foto profil." });
        }
    }
};
