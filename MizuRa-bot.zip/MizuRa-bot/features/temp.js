const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const dbPath = path.join(__dirname, '../database/user_data.json');
const readDB = () => { try { return JSON.parse(fs.readFileSync(dbPath, 'utf-8')); } catch { return {}; } };
const writeDB = (data) => { fs.writeFileSync(dbPath, JSON.stringify(data, null, 2)); };

module.exports = {
    // Properti buat Loader Menu Otomatis & UI Baru
    help: 'temp',
    category: 'tools',
    desc: 'layanan email', 
    execute: async (sock, msg, args, from) => {
        const action = args[0] ? args[0].toLowerCase() : 'create';
        let db = readDB();

        if (action === 'create') {
            try {
                if (db[from]) return sock.sendMessage(from, { text: `❌ Lu masih punya email aktif: *${db[from].email}*\n\nHapus dulu pakai *${config.prefix}temp del* kalau mau buat baru.` });
                
                await sock.sendMessage(from, { text: '⏳ Sedang membuat email baru...' }, { quoted: msg });
                const domainRes = await fetch('https://api.mail.tm/domains');
                const domainData = await domainRes.json();
                const domain = domainData['hydra:member'][0].domain;
                const email = `mizura_${crypto.randomBytes(3).toString('hex')}@${domain}`;
                const password = 'mizura_password';

                await fetch('https://api.mail.tm/accounts', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ address: email, password: password })
                });

                const tokenRes = await fetch('https://api.mail.tm/token', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ address: email, password: password })
                });
                const tokenData = await tokenRes.json();

                db[from] = { email: email, token: tokenData.token };
                writeDB(db);

                await sock.sendMessage(from, { text: `✅ *Email Berhasil Dibuat!*\n\n📧 *Email:* ${email}\n\nKetik *${config.prefix}temp cek* untuk cek inbox.` }, { quoted: msg });
            } catch (e) { await sock.sendMessage(from, { text: '❌ Gagal membuat email.' }); }
        } 
        else if (action === 'cek') {
            const user = db[from];
            if (!user) return sock.sendMessage(from, { text: `Kamu belum punya email. Gunakan *${config.prefix}temp* untuk membuat.` });
            try {
                const msgRes = await fetch('https://api.mail.tm/messages', {
                    headers: { 'Authorization': `Bearer ${user.token}` }
                });
                const msgData = await msgRes.json();
                const items = msgData['hydra:member'];
                if (items.length === 0) return sock.sendMessage(from, { text: '📭 Kotak masuk kosong.' });
                let txt = `📬 *Inbox ${user.email}*\n\n`;
                items.forEach((m, i) => { txt += `*${i+1}. Dari:* ${m.from.address}\n*Subjek:* ${m.subject}\n*Isi:* ${m.intro}\n\n`; });
                await sock.sendMessage(from, { text: txt }, { quoted: msg });
            } catch (e) { await sock.sendMessage(from, { text: '❌ Gagal mengecek inbox.' }); }
        }
        else if (action === 'hapus' || action === 'del') {
            if (!db[from]) return sock.sendMessage(from, { text: "❌ Lu emang nggak punya email aktif, Sur." }, { quoted: msg });

            if (!args[1]) {
                return sock.sendMessage(from, { 
                    text: `⚠️ *KONFIRMASI PENGHAPUSAN*\n\nEmail lu saat ini: *${db[from].email}*\n\nKalau yakin mau hapus, ketik:\n*${config.prefix}temp del ${db[from].email}*` 
                }, { quoted: msg });
            }

            if (args[1] === db[from].email) {
                const emailLama = db[from].email;
                delete db[from];
                writeDB(db);
                await sock.sendMessage(from, { text: `🗑️ *Sukses!* Email *${emailLama}* udah dihapus dari database.` }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: "❌ Nama email yang lu masukin salah. Cek lagi tulisannya!" }, { quoted: msg });
            }
        }
    }
};
