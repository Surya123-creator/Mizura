const axios = require('axios');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../database/sent_anime.json');
const ID_GRUP = '120363425076428013@g.us';
const ID_SALURAN = '120363426938337958@newsletter';

async function broadcastAnime(sock, from = null) {
    try {
        const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
        const today = dayNames[new Date().getDay()];
        
        const { data } = await axios.get(`https://api.jikan.moe/v4/schedules?filter=${today}`, { timeout: 15000 });
        const animeList = data.data;

        let sentAnimes = JSON.parse(fs.readFileSync(dbPath));

        // --- KONDISI MANUAL (.jadwalanime) ---
        if (from) {
            // Kita ambil 10 anime pertama buat dirangkum jadi 1 pesan
            let listAnime = animeList.slice(0, 10);
            let teksManual = `╔═══〔 📅 *JADWAL HARI INI* 〕═══╗\n║ Hari: ${today.toUpperCase()}\n╚═══════════════════════╝\n\n`;
            
            listAnime.forEach((a, i) => {
                teksManual += `${i + 1}. *${a.title}*\n   🕒 Jam: ${a.broadcast?.string || 'N/A'}\n   🌟 Skor: ${a.score || 'N/A'}\n\n`;
            });
            
            teksManual += `_Ketik link di bawah untuk detail lebih lanjut_`;

            // Kirim ke yang ngetik command (Pake gambar anime urutan pertama)
            return await sock.sendMessage(from, { 
                image: { url: listAnime[0].images.jpg.large_image_url }, 
                caption: teksManual 
            });
        }

        // --- KONDISI AUTO (DICICIL 1) ---
        const anime = animeList.find(a => !sentAnimes.includes(a.mal_id));

        if (!anime) {
            console.log(`[ SYSTEM ] Semua jadwal hari ini sudah terkirim.`);
            return false;
        }

        const genres = anime.genres?.map(g => g.name).slice(0, 3).join(", ") || "Unknown";
        let caption = `╔═══〔 🎴 𝐀𝐍𝐈𝐌𝐄 𝐔𝐏𝐃𝐀𝐓𝐄 〕═══╗\n║ 🎬 𝐓𝐢𝐭𝐥𝐞 : ${anime.title}\n║ 🌟 𝐒𝐜𝐨𝐫 : ${anime.score || 'N/A'}\n║ 📺 𝐄𝐩𝐢𝐬𝐨𝐝𝐞 : ${anime.episodes || '?'}\n║ 🎭 𝐆𝐞𝐧𝐫𝐞 : ${genres}\n║ 🕒 𝐀𝐢𝐫𝐢𝐧𝐠 : ${anime.broadcast?.string || 'Unknown'}\n╚═══════════════════════╝\n\n🔗 ${anime.url}\n✦ MizuRa Tracker`;

        console.log(`[ AUTO ] Mengirim: ${anime.title}`);
        
        // Grup (Gambar)
        await sock.sendMessage(ID_GRUP, { image: { url: anime.images.jpg.large_image_url }, caption: caption });
        // Saluran (Teks)
        await sock.sendMessage(ID_SALURAN, { text: caption });

        sentAnimes.push(anime.mal_id);
        fs.writeFileSync(dbPath, JSON.stringify(sentAnimes));
        
        return true;

    } catch (e) {
        console.error("Anime Error:", e.message);
        return false;
    }
}

module.exports = {
    help: 'jadwalanime',
    category: 'anime',
    desc: 'anime hari ini',
    execute: async (sock, msg, args, from) => {
        // Kasih reaksi atau pesan nunggu biar berasa responsif
        await sock.sendMessage(from, { text: "🔍 Membuka buku jadwal..." });
        await broadcastAnime(sock, from);
    },
    broadcastAnime
};
