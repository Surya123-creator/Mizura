const isekaiDB = require('../isekai_db');

module.exports = {
    help: 'inventory',
    category: 'isekai',
    desc: 'Cek isi tas',
    execute: async (sock, msg, args, from) => {
        try {
            let db = isekaiDB.read();
            
            // --- FIX: Pakai msg.sender supaya inventory tidak bercampur ---
            const playerID = msg.sender; 
            db = isekaiDB.checkUser(db, playerID);
            const user = db[playerID];

            if (!user.inventory || user.inventory.length === 0) {
                return sock.sendMessage(from, { 
                    text: `╔═══〔 🎒 𝐈𝐧𝐯𝐞𝐧𝐭𝐨𝐫𝐲 〕═══╗
║ ❌ Tas kosong...
╚═══════════════════╝

✧ Belum ada item, Sur.
✧ Pergilah berburu dengan *.hunt*`
                }, { quoted: msg });
            }

            // ===== KATEGORI =====
            const consumables = [];
            const gear = [];
            const loot = [];

            user.inventory.forEach(item => {
                const name = item.toLowerCase();
                if (name.includes('potion') || name.includes('elixir')) {
                    consumables.push(item);
                } else if (
                    name.includes('sword') ||
                    name.includes('armor') ||
                    name.includes('shield') ||
                    name.includes('blade')
                ) {
                    gear.push(item);
                } else {
                    loot.push(item);
                }
            });

            // ===== FORMAT COUNT =====
            const formatList = (arr) => {
                let counts = {};
                arr.forEach(x => counts[x] = (counts[x] || 0) + 1);

                return Object.entries(counts)
                    .map(([name, count]) => `│ ✦ ${name} 〔x${count}〕`)
                    .join("\n");
            };

            // ===== HEADER =====
            let teks = `╔═══〔 ✦ 𝐈𝐧𝐯𝐞𝐧𝐭𝐨𝐫𝐲 〕═══╗
║ 👤 𝐍𝐚𝐦𝐚 : ${msg.pushName || 'Player'}
║ 💰 𝐌𝐨𝐫𝐚 : ${user.money.toLocaleString()}
║ 🎒 𝐓𝐨𝐭𝐚𝐥 : ${user.inventory.length} item
╚═════════════════════╝\n\n`;

            // ===== SECTION =====
            if (consumables.length > 0) {
                teks += `╔══〔 🧪 𝐂𝐨𝐧𝐬𝐮𝐦𝐚𝐛𝐥𝐞𝐬 〕══╗\n`;
                teks += `${formatList(consumables)}\n`;
                teks += `╚═════════════════════╝\n\n`;
            }

            if (gear.length > 0) {
                teks += `╔══〔 ⚔️ 𝐆𝐞𝐚𝐫 〕══╗\n`;
                teks += `${formatList(gear)}\n`;
                teks += `╚═════════════════════╝\n\n`;
            }

            if (loot.length > 0) {
                teks += `╔══〔 💎 𝐋𝐨𝐨𝐭 〕══╗\n`;
                teks += `${formatList(loot)}\n`;
                teks += `╚═════════════════════╝\n\n`;
            }

            // ===== FOOTER =====
            teks += `╔═══〔 ✦ 𝐈𝐧𝐟𝐨 〕═══╗
║ ✧ Gunakan item:
║   *.use [nama]*
║ ✧ Contoh:
║   .use Potion
╚══════════════════╝

✧ Tas petualangmu siap digunakan...`;

            // Tetap kirim ke 'from' (group/private chat), tapi datanya ambil dari 'playerID'
            await sock.sendMessage(from, { text: teks }, { quoted: msg });

        } catch (e) {
            console.error(e);
            await sock.sendMessage(from, { text: "⚠️ Gagal membuka inventory." });
        }
    }
};
