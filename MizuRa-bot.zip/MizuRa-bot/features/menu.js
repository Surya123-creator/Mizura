const fs = require('fs');
const path = require('path');
const config = require('../config');

// Fungsi buat itung Uptime (Lama bot nyala)
function runtime(seconds) {
    seconds = Number(seconds);
    var d = Math.floor(seconds / (3600 * 24));
    var h = Math.floor(seconds % (3600 * 24) / 3600);
    var m = Math.floor(seconds % 3600 / 60);
    var s = Math.floor(seconds % 60);
    return `${d}h ${h}j ${m}m ${s}s`;
}

module.exports = {
    help: 'menu',
    category: 'system',
    desc: 'All Perintah',
    execute: async (sock, msg, args, from) => {
        try {
            const featuresDir = path.join(__dirname, '../features');
            const featureFiles = fs.readdirSync(featuresDir).filter(file => file.endsWith('.js'));

            const imagePath = path.join(__dirname, '../gambar/menu.jpg');
            
            let categories = {};

            // Proses scan fitur & kategori
            featureFiles.forEach(file => {
                const feature = require(path.join(featuresDir, file));
                
                // --- FILTER HIDDEN (Kunci fiturnya di sini) ---
                if (!feature.help || feature.category === 'hidden') return;

                const cat = feature.category || 'OTHER';
                if (!categories[cat]) categories[cat] = [];
                categories[cat].push({
                    help: feature.help,
                    desc: feature.desc || 'tidak ada deskripsi'
                });
            });

            // Rakit Tampilan Menu
            let menuText = `╭───「 ✦ ${config.botName} ✦ 」\n`;
            menuText += `│ ✦ Owner   : @${config.owner ? config.owner.split('@')[0] : 'Admin'}\n`;
            menuText += `│ ✦ Uptime  : ${runtime(process.uptime())}\n`;
            menuText += `│ ✦ Status  : ✧ Online ✧\n`;
            menuText += `╰──────────────────────\n\n`;

            // Susun berdasarkan kategori
            const keys = Object.keys(categories).sort();
            for (const key of keys) {
                menuText += `╭───「 ✦ ${key.toUpperCase()} ✦ 」\n`;
                categories[key].forEach(cmd => {
                    menuText += `│ ✧ ${config.prefix}${cmd.help}  › ${cmd.desc}\n`;
                });
                menuText += `╰──────────────────────\n\n`;
            }

            menuText += `_✦ ${config.botName} • Newbie Project ✦_`;

            // Kirim dengan gambar atau teks saja
            if (fs.existsSync(imagePath)) {
                await sock.sendMessage(from, { 
                    image: fs.readFileSync(imagePath), 
                    caption: menuText,
                    mentions: [config.owner + '@s.whatsapp.net']
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: menuText }, { quoted: msg });
                console.log("⚠️ Gambar tidak ditemukan di:", imagePath);
            }

        } catch (e) {
            console.error("Menu error:", e);
            await sock.sendMessage(from, { text: "⚠️ Terjadi kesalahan saat memuat menu." });
        }
    }
};
