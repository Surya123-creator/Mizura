const isekaiDB = require('../isekai_db');

module.exports = {
    help: 'use',
    category: 'hidden',
    desc: 'Gunakan item pemulihan',
    execute: async (sock, msg, args, from) => {
        let db = isekaiDB.read();
        
        // --- FIX: Ambil data berdasarkan nomor pengirim (msg.sender) ---
        const playerID = msg.sender;
        db = isekaiDB.checkUser(db, playerID);

        if (!args[0]) return sock.sendMessage(from, { text: "❌ Mau pakai apa? Contoh: *.use Potion*" });

        const itemName = args.join(" ");
        const userInv = db[playerID].inventory || [];
        const itemIndex = userInv.findIndex(i => i.toLowerCase() === itemName.toLowerCase());

        if (itemIndex === -1) {
            return sock.sendMessage(from, { text: `❌ Kamu tidak memiliki *${itemName}* di tas!` });
        }

        // --- VALIDASI DATA (Anti NaN/Undefined) ---
        if (!db[playerID].max_hp) db[playerID].max_hp = 100 + (db[playerID].level * 20);
        if (db[playerID].hp === undefined) db[playerID].hp = db[playerID].max_hp;

        if (db[playerID].hp >= db[playerID].max_hp) {
            return sock.sendMessage(from, { text: `❌ Darah kamu masih penuh!` }, { quoted: msg });
        }

        const itemLower = itemName.toLowerCase();
        let log = "";
        let beforeHP = db[playerID].hp;
        let heal = 0;

        // --- LOGIKA ITEM ---
        if (itemLower === 'potion') {
            heal = 150;
            db[playerID].hp = Math.min(db[playerID].max_hp, db[playerID].hp + heal);
            log = "🧪 Potion diminum... luka mulai pulih.";
        } else if (itemLower === 'hi-potion') {
            heal = 300;
            db[playerID].hp = Math.min(db[playerID].max_hp, db[playerID].hp + heal);
            log = "🧴 Hi-Potion digunakan... pemulihan besar terjadi.";
        } else if (itemLower === 'elixir' || itemLower === 'mega elixir') {
            db[playerID].hp = db[playerID].max_hp;
            log = itemLower === 'elixir' ? "🥛 Elixir diminum... HP penuh!" : "🌟 Mega Elixir! Status pulih total.";
        } else {
            return sock.sendMessage(from, { text: `❌ Item *${itemName}* tidak bisa digunakan.` }, { quoted: msg });
        }

        const actualHeal = db[playerID].hp - beforeHP;

        // Eksekusi: Hapus item dari tas pribadi
        db[playerID].inventory.splice(itemIndex, 1);
        isekaiDB.write(db);

        // --- UI OUTPUT ---
        await sock.sendMessage(from, {
            text: `╔══〔 ✦ 𝐔𝐬𝐞 𝐈𝐭𝐞𝐦 ✦ 〕══╗
║ 👤 𝐔𝐬𝐞𝐫 : @${playerID.split('@')[0]}
║ 📦 𝐈𝐭𝐞𝐦 : ${itemName.toUpperCase()}
║
║ ${log}
║
║ ❤️ +${actualHeal} HP
║ 💖 ${db[playerID].hp} / ${db[playerID].max_hp}
╚════════════════════╝
${db[playerID].hp === db[playerID].max_hp ? "✨ HP FULL!" : ""}`,
            mentions: [playerID]
        }, { quoted: msg });
    }
};
