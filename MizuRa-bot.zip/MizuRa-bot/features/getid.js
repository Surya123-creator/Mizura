module.exports = {
    help: 'getid',
    category: 'zotther',
    desc: 'cek id',
    execute: async (sock, msg, args, from) => {
        await sock.sendMessage(from, { text: `ID Chat ini: ${from}` });
    }
};
