const isekaiDB = require('../isekai_db');

const COOLDOWN = 15000;

// ===== MONSTER DATA =====
const baseMonsters = [
"Slime","Goblin","Orc","Dragon","Wyvern","Hydra","Griffin","Phoenix","Kraken",
"Skeleton","Zombie","Ghoul","Lich","Vampire","Werewolf","Dullahan","Banshee",
"Golem","Demon","Succubus","Minotaur","Cyclops","Ogre","Troll",
"Harpy","Siren","Fairy","Shadow","Void Entity","Knight","Samurai",
"Titan","Leviathan","Elemental","Angel","Fallen Angel","Dragon King"
];

const prefixes = ["Ancient","Dark","Cursed","Savage","Infernal","Holy","Void"];
const suffixes = ["of Doom","of Abyss","the Destroyer","the Fallen"];
const elements = ["🔥 Fire","❄️ Ice","⚡ Lightning","🌪️ Wind","🌑 Dark","🌟 Light"];

// ===== RARITY & MULTIPLIER =====
const rarities = [
    { name: "F", icon: "⚫", chance: 30, multi: 0.8 },
    { name: "E", icon: "⚪", chance: 25, multi: 1 },
    { name: "D", icon: "🟢", chance: 18, multi: 1.3 },
    { name: "C", icon: "🔵", chance: 12, multi: 1.8 },
    { name: "B", icon: "🟣", chance: 8, multi: 2.5 },
    { name: "A", icon: "🟡", chance: 4.5, multi: 4 },
    { name: "S", icon: "🟠", chance: 1.8, multi: 6 },
    { name: "SS", icon: "🔴", chance: 0.5, multi: 9 },
    { name: "SSS", icon: "🔥", chance: 0.15, multi: 13 },
    { name: "SSSS", icon: "💀", chance: 0.05, multi: 20 }
];

const items = [
    { name: "Potion", chance: 40 },
    { name: "Hi-Potion", chance: 15 },
    { name: "Elixir", chance: 10 },
    { name: "Mega Elixir", chance: 2 },
    { name: "Crystal", chance: 20 },
    { name: "Magic Core", chance: 10 },
    { name: "Ancient Relic", chance: 3 }
];

const flavorTexts = [
    "Aura nya bikin merinding...",
    "Kayaknya ini bukan musuh sembarangan.",
    "Kamu agak menyesal melawan ini.",
    "Monster ini terlihat sangat lapar.",
    "Suasananya langsung berubah dingin."
];

// ===== UTIL =====
function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function random(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function pickByChance(arr) {
    const total = arr.reduce((sum, a) => sum + a.chance, 0);
    let r = Math.random() * total;
    for (let item of arr) {
        if (r < item.chance) return item;
        r -= item.chance;
    }
}

function generateMonster(playerLevel = 1) {
    let rarity = pickByChance(rarities);
    if (playerLevel < 15 && ["S","SS","SSS","SSSS"].includes(rarity.name)) rarity = rarities[0];
    if (playerLevel < 30 && ["SS","SSS","SSSS"].includes(rarity.name)) rarity = rarities[2];

    return {
        name: `${random(prefixes)} ${random(baseMonsters)} ${random(suffixes)}`,
        rarity,
        element: random(elements),
        level: rand(1, playerLevel * 5 + 10),
        flavor: random(flavorTexts)
    };
}

// ===== MAIN EXECUTE =====
module.exports = {
    help: 'hunt',
    category: 'isekai',
    desc: 'Berburu ',
    execute: async (sock, msg, args, from) => {
        let db = isekaiDB.read();
        
        // --- FIX: Pakai msg.sender supaya data tidak bentrok ---
        const playerID = msg.sender; 
        db = isekaiDB.checkUser(db, playerID);

        if (db[playerID].hp <= 0) {
            return sock.sendMessage(from, { 
                text: `❌ *KONDISI KRITIS* ❌\nHP kamu 0. Pulihkan diri dengan *.use Potion* sebelum berburu lagi!` 
            }, { quoted: msg });
        }

        const now = Date.now();
        const diff = now - (db[playerID].lastHunt || 0);
        if (diff < COOLDOWN) {
            const sisa = Math.ceil((COOLDOWN - diff) / 1000);
            return sock.sendMessage(from, { text: `⏳ Mohon tunggu *${sisa} detik* lagi.` }, { quoted: msg });
        }

        db[playerID].lastHunt = now;
        const playerLevel = db[playerID].level || 1;
        const monster = generateMonster(playerLevel);

        let money = Math.floor((rand(300, 1000) + monster.level * 15) * monster.rarity.multi);
        let exp = Math.floor((rand(80, 200) + monster.level * 8) * monster.rarity.multi);
        
        let baseDmg = rand(15, 35) + monster.level * 2;
        let damage = Math.floor(baseDmg * monster.rarity.multi);
        
        // Minimal darah tersisa 1 kalau damage terlalu besar
        if (damage >= db[playerID].hp) damage = Math.floor(db[playerID].hp * 0.9);

        db[playerID].money += money;
        db[playerID].exp += exp;
        db[playerID].hp -= damage;
        if (db[playerID].hp < 0) db[playerID].hp = 0;

        if (!db[playerID].inventory) db[playerID].inventory = [];
        let drops = [];
        let dropCount = rand(1, 2);
        for (let i = 0; i < dropCount; i++) {
            let itemDrop = pickByChance(items);
            db[playerID].inventory.push(itemDrop.name);
            drops.push(itemDrop.name);
        }

        let levelUp = false;
        let needExp = playerLevel * 1200;
        if (db[playerID].exp >= needExp) {
            db[playerID].level += 1;
            db[playerID].exp -= needExp;
            db[playerID].max_hp += 100;
            db[playerID].hp = db[playerID].max_hp;
            levelUp = true;
        }

        isekaiDB.write(db);

        const caption = `╔═══〔 ✦ 𝐀𝐝𝐯𝐞𝐧𝐭𝐮𝐫𝐞 𝐋𝐨𝐠 ✦ 〕═══╗
║ ${monster.rarity.icon} 𝐑𝐚𝐧𝐤 : ${monster.rarity.name}
║ 👾 𝐄𝐧𝐞𝐦𝐲 : ${monster.name}
║ 🌐 𝐄𝐥𝐞𝐦𝐞𝐧𝐭 : ${monster.element}
║ 🆙 𝐋𝐯 : ${monster.level}
║ ❤️ 𝐇𝐏 : ${db[playerID].hp} / ${db[playerID].max_hp} (-${damage})
║
║ ❝ ${monster.flavor} ❞
║
╠═══〔 ✦ 𝐑𝐞𝐰𝐚𝐫𝐝𝐬 ✦ 〕═══╣
║ 💰 𝐌𝐨𝐫𝐚 : +${money.toLocaleString()}
║ ✨ 𝐄𝐗𝐏  : +${exp.toLocaleString()}
║ 📦 𝐋𝐨𝐨𝐭 : ${drops.join(", ")}
╚═══════════════════════╝

${db[playerID].hp <= 20 ? "⚠️ *WARNING:* Darah kritis! Segera gunakan pemulih!" : ""}
${monster.rarity.name === "SSSS" ? "🌌 ✦ REALITY SHAKES... LEGEND HAS FALLEN ✦" : ""}

✧ Perjalanan berlanjut...`;

        await sock.sendMessage(from, { text: caption }, { quoted: msg });

        if (levelUp) {
            await sock.sendMessage(from, { 
                text: `🎊 *LEVEL UP!* 🎊\nSelamat @${playerID.split('@')[0]}! Kamu naik ke Level *${db[playerID].level}*!\n❤️ Max HP meningkat +100!`,
                mentions: [playerID]
            });
        }
    }
};
