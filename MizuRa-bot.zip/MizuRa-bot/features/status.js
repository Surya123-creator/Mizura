const isekaiDB = require('../isekai_db');
const fs = require('fs');
const path = require('path');

function getPlayerRank(level) {
    if (level >= 80) return "SSSS";
    if (level >= 65) return "SSS";
    if (level >= 50) return "SS";
    if (level >= 40) return "S";
    if (level >= 30) return "A";
    if (level >= 22) return "B";
    if (level >= 15) return "C";
    if (level >= 10) return "D";
    if (level >= 5) return "E";
    return "F";
}

module.exports = {
    help: 'status',
    category: 'isekai',
    desc: 'Cek profil pribadi',
    execute: async (sock, msg, args, from) => {
        try {
            // --- SUPER ID GRABBER ---
            // Mengambil ID dari pengirim pesan asli, baik di grup maupun pribadi
            const playerID = msg.key.participant || msg.key.remoteJid || msg.sender;
            
            // Log ke Termux buat mastiin nomor siapa yang kedetek
            console.log(`[ISEKAI] Checking status for: ${playerID}`);

            if (!playerID || playerID.includes('@g.us') && !msg.key.participant) {
                return sock.sendMessage(from, { text: "❌ Gagal mendeteksi ID pemain." });
            }

            let db = isekaiDB.read();
            db = isekaiDB.checkUser(db, playerID);
            
            const dataUser = db[playerID];

            // Ambil angka depannya saja untuk folder foto profil agar lebih aman
            const pushKontak = playerID.split('@')[0];
            const ppPath = path.join(__dirname, '../database/profiles', `${pushKontak}.jpg`);
            const hasPP = fs.existsSync(ppPath);

            const playerRank = getPlayerRank(dataUser.level);
            let title = dataUser.level >= 70 ? "Legend" : dataUser.level >= 40 ? "Master" : dataUser.level >= 20 ? "Elite" : dataUser.level >= 10 ? "Adventurer" : "Novice";

            const maxBar = 10;
            const hpRatio = Math.min(Math.max(dataUser.hp / dataUser.max_hp, 0), 1);
            const filledHP = Math.round(hpRatio * maxBar);
            const hpBar = '🟩'.repeat(filledHP) + '⬛'.repeat(maxBar - filledHP);

            const needExp = (dataUser.level || 1) * 1200;
            const expRatio = Math.min(Math.max(dataUser.exp / needExp, 0), 1);
            const filledEXP = Math.round(expRatio * maxBar);
            const expBar = '🟦'.repeat(filledEXP) + '⬛'.repeat(maxBar - filledEXP);

            let teks = `╔═══〔 ✦ *HERO CARD* ✦ 〕═══╗\n`;
            teks += `║ 👤 *Nama* : ${msg.pushName || 'Adventurer'}\n`;
            teks += `║ 🆔 *User* : @${pushKontak}\n`;
            teks += `║ 🏅 *Rank* : ${playerRank}\n`;
            teks += `║ 🎖️ *Title* : ${title}\n`;
            teks += `║ 🆙 *Level* : ${dataUser.level}\n`;
            teks += `║ 💰 *Mora* : ${dataUser.money.toLocaleString()}\n`;
            teks += `╚═══════════════════════╝\n\n`;

            teks += `╔══〔 ❤️ *VITAL* 〕══╗\n`;
            teks += `║ HP : ${dataUser.hp}/${dataUser.max_hp}\n`;
            teks += `║ ${hpBar} ${Math.floor(hpRatio * 100)}%\n`;
            teks += `╚═══════════════════════╝\n\n`;

            teks += `╔══〔 ✨ *PROGRESS* 〕══╗\n`;
            teks += `║ EXP : ${dataUser.exp}/${needExp}\n`;
            teks += `║ ${expBar} ${Math.floor(expRatio * 100)}%\n`;
            teks += `╚═══════════════════════╝\n\n`;

            if (!hasPP) teks += `_💡 Tips: Reply foto dengan *.setpp*_\n`;

            // Kirim pesan dengan mention spesifik ke pengirim
            const sendOptions = { 
                mentions: [playerID],
                quoted: msg 
            };

            if (hasPP) {
                await sock.sendMessage(from, { 
                    image: { url: ppPath }, 
                    caption: teks,
                    ...sendOptions
                });
            } else {
                await sock.sendMessage(from, { 
                    text: teks,
                    ...sendOptions
                });
            }

        } catch (e) {
            console.error("Error di status.js:", e);
            await sock.sendMessage(from, { text: "⚠️ Terjadi kesalahan sistem saat memuat status." });
        }
    }
};
