const connectToWhatsApp = require('./sockets/connect.js');
const animeFunc = require('./features/jadwalanime');
const fs = require('fs');

console.log("\x1b[36m✦ Menjalankan MizuRa-bot...\x1b[0m");
console.log("\x1b[33m✦ Status: Opening...\x1b[0m");

// ===== HITUNG DELAY KE JAM 00:00 =====
function getMsToMidnight() {
    const now = new Date();
    const midnight = new Date();
    midnight.setHours(24, 0, 0, 0);
    return midnight - now;
}

async function startBot() {
    try {
        const sock = await connectToWhatsApp();

        console.log("\x1b[32m[ SYSTEM ] Auto-Broadcast Anime Aktif (Mode Cicil 30 Menit)!\x1b[0m");

        // --- SISTEM CICIL ANTREAN ---
        
        // 1. Jalankan langsung pas bot nyala (Test kirim antrean pertama)
        console.log('\x1b[34m[ SYSTEM ] Mengirim antrean anime pertama...\x1b[0m');
        await animeFunc.broadcastAnime(sock);

        // 2. Set timer untuk mengirim antrean berikutnya setiap 30 menit
        // 1.800.000 ms = 30 Menit
        setInterval(async () => {
            console.log('\x1b[34m[ SYSTEM ] Menjalankan pengecekan antrean (Interval 30 Menit)...\x1b[0m');
            await animeFunc.broadcastAnime(sock);
        }, 1800000); 

        // ===== RESET DATABASE TEPAT JAM 00:00 =====
        const resetDB = () => {
            const db = './database/sent_anime.json';
            if (fs.existsSync(db)) {
                fs.writeFileSync(db, JSON.stringify([]));
                console.log("\x1b[35m[ SYSTEM ] Database anime direset (Hari Baru).\x1b[0m");
            }
        };

        // Pasang timer reset harian agar antrean mulai dari awal setiap harinya
        setTimeout(() => {
            resetDB();
            setInterval(resetDB, 86400000);
        }, getMsToMidnight());

    } catch (err) {
        console.error("\x1b[31m[ CRASH ] Bot gagal jalan:\x1b[0m", err);
    }
}

startBot();
