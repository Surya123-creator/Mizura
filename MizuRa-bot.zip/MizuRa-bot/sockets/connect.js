const { // Pastikan "c" kecil
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeCacheableSignalKeyStore, 
    Browsers 
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const config = require('../config');
const handler = require('./Hendler');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('./mizura_session');
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        browser: Browsers.ubuntu('Chrome'),
        markOnlineOnConnect: true
    });

    if (!sock.authState.creds.registered) {
        let phoneNumber = await question('\x1b[33mMasukkan Nomor Bot (628xxx): \x1b[0m');
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
        
        setTimeout(async () => {
            let code = await sock.requestPairingCode(phoneNumber);
            code = code?.match(/.{1,4}/g)?.join("-") || code;
            console.log(`\n\x1b[32mKODE PAIRING LU: ${code}\x1b[0m\n`);
        }, 3000);
    }

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) connectToWhatsApp();
        } else if (connection === 'open') {
            console.log('\n\x1b[32m[ SUCCESS ] BOT ONLINE SEKARANG!\x1b[0m\n');
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // Bagian ini yang krusial buat respon perintah
    sock.ev.on('messages.upsert', async (upsert) => {
        try {
            // Kita pastiin data yang dikirim ke Hendler itu bener
            if (!upsert.messages) return;
            await handler(sock, upsert);
        } catch (e) {
            console.error("Error di Handler:", e);
        }
    });

    return sock;
}

module.exports = connectToWhatsApp;
