const fs = require('fs');
const path = require('path');
const config = require('../config');

module.exports = async (sock, m) => {
    try {
        if (!m || !m.messages) return;
        const msg = m.messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const from = msg.key.remoteJid;
        
        // --- TAMBAHAN: Definisi Sender yang Akurat ---
        const isGroup = from.endsWith('@g.us');
        const sender = isGroup ? msg.key.participant : from;
        
        // Masukin sender ke dalam objek msg biar bisa dibaca di file fitur
        msg.sender = sender;

        const type = Object.keys(msg.message)[0];
        const body = (type === 'conversation') 
            ? msg.message.conversation 
            : (type === 'extendedTextMessage') 
                ? msg.message.extendedTextMessage.text 
                : (type === 'imageMessage') 
                    ? msg.message.imageMessage.caption 
                    : (type === 'videoMessage') 
                        ? msg.message.videoMessage.caption 
                        : '';

        if (!body.startsWith(config.prefix)) return;

        const args = body.slice(config.prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();
        
        const featureFile = path.join(__dirname, '../features', `${command}.js`);

        if (fs.existsSync(featureFile)) {
            delete require.cache[require.resolve(featureFile)];
            const feature = require(featureFile);

            if (feature && feature.execute) {
                // Sekarang file fitur bisa baca msg.sender dengan aman
                await feature.execute(sock, msg, args, from);
            }
        }
    } catch (err) { 
        console.error("---> [DEBUG] ERROR DI HENDLER:", err); 
    }
};
